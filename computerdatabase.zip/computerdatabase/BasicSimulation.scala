package computerdatabase

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class BasicSimulation extends Simulation {

	val httpProtocol = http
		.baseURL("http://computer-database.herokuapp.com")
		.inferHtmlResources()
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate")
		.acceptLanguageHeader("en-US,en;q=0.5")
		.userAgentHeader("Mozilla/5.0 (Windows NT 6.1; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0")

	val headers_0 = Map("Upgrade-Insecure-Requests" -> "1")



	val scn = scenario("BasicSimulation")
		// Search
		.exec(http("request_0")
			.get("/computers?f=macbook")
			.headers(headers_0))
		.pause(21)
		.exec(http("request_1")
			.get("/computers/6")
			.headers(headers_0))
		.pause(16)
		// Browse
		.exec(http("request_2")
			.get("/computers")
			.headers(headers_0))
		.pause(22)
		.exec(http("request_3")
			.get("/computers?p=1")
			.headers(headers_0))
		.pause(1)
		.exec(http("request_4")
			.get("/computers?p=2")
			.headers(headers_0))
		.pause(1)
		.exec(http("request_5")
			.get("/computers?p=3")
			.headers(headers_0))
		.pause(6)
		.exec(http("request_6")
			.get("/computers?p=4")
			.headers(headers_0))
		.pause(1)
		.exec(http("request_7")
			.get("/computers?p=5")
			.headers(headers_0))
		.pause(2)
		.exec(http("request_8")
			.get("/computers?p=6")
			.headers(headers_0))
		.pause(1)
		.exec(http("request_9")
			.get("/computers?p=7")
			.headers(headers_0))
		.pause(23)
		// Edit
		.exec(http("request_10")
			.get("/computers/new")
			.headers(headers_0))
		.pause(45)
		.exec(http("request_11")
			.post("/computers")
			.headers(headers_0)
			.formParam("name", "Test-Manisha")
			.formParam("introduced", "2016-09-07")
			.formParam("discontinued", "2016-09-08")
			.formParam("company", "42"))

	setUp(scn.inject(atOnceUsers(1))).protocols(httpProtocol)
}